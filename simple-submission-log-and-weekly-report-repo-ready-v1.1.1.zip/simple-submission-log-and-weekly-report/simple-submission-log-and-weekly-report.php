<?php
/**
 * Plugin Name:       Simple Submission Log and Weekly Report
 * Plugin URI:        https://www.linkedin.com/in/shajolkundu/
 * Description:       Stores website form submissions in WordPress admin, supports CSV export, and emails a weekly CSV report to the site admin or chosen recipients.
 * Version:           1.1.1
 * Requires at least: 6.2
 * Requires PHP:      7.4
 * Author:            shajol
 * Author URI:        https://www.linkedin.com/in/shajolkundu/
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       simple-submission-log-weekly-report
 * Domain Path:       /languages
 *
 * @package Simple_Submission_Log_Weekly_Report
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'M4U_Simple_Submission_Log_Weekly_Report' ) ) {
	/**
	 * Main plugin class.
	 */
	class M4U_Simple_Submission_Log_Weekly_Report {
		/**
		 * Plugin version.
		 *
		 * @var string
		 */
		const VERSION = '1.1.1';

		/**
		 * Database table suffix.
		 *
		 * @var string
		 */
		const TABLE_SUFFIX = 'm4u_submission_log';

		/**
		 * Settings option key.
		 *
		 * @var string
		 */
		const OPTION_KEY = 'm4u_simple_submission_log_settings';

		/**
		 * Cron hook.
		 *
		 * @var string
		 */
		const CRON_HOOK = 'm4u_simple_submission_log_send_weekly_report';

		/**
		 * Menu slug.
		 *
		 * @var string
		 */
		const MENU_SLUG = 'm4u-submission-log';

		/**
		 * Initialize the plugin.
		 *
		 * @return void
		 */
		public static function init() {
			add_action( 'plugins_loaded', array( __CLASS__, 'load_textdomain' ) );
			add_action( 'admin_menu', array( __CLASS__, 'register_admin_menu' ) );
			add_action( 'admin_init', array( __CLASS__, 'register_settings' ) );
			add_action( 'admin_init', array( __CLASS__, 'maybe_add_privacy_content' ) );
			add_filter( 'cron_schedules', array( __CLASS__, 'add_weekly_schedule' ) );
			add_action( self::CRON_HOOK, array( __CLASS__, 'send_weekly_report' ) );
			add_action( 'admin_post_m4u_submission_export_csv', array( __CLASS__, 'handle_export_csv' ) );
			add_action( 'admin_post_m4u_submission_send_report_now', array( __CLASS__, 'handle_send_report_now' ) );
			add_action( 'm4u_submission_logger_capture', array( __CLASS__, 'capture_submission' ), 10, 2 );

			add_filter( 'wp_privacy_personal_data_exporters', array( __CLASS__, 'register_privacy_exporter' ) );
			add_filter( 'wp_privacy_personal_data_erasers', array( __CLASS__, 'register_privacy_eraser' ) );

			self::register_form_hooks();
		}

		/**
		 * Load translations.
		 *
		 * @return void
		 */
		public static function load_textdomain() {
			load_plugin_textdomain( 'simple-submission-log-weekly-report', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );
		}

		/**
		 * Register supported form hooks.
		 *
		 * @return void
		 */
		public static function register_form_hooks() {
			add_action( 'wpcf7_mail_sent', array( __CLASS__, 'capture_cf7_submission' ) );
			add_action( 'wpforms_process_complete', array( __CLASS__, 'capture_wpforms_submission' ), 10, 4 );
			add_action( 'fluentform_submission_inserted', array( __CLASS__, 'capture_fluent_forms_submission' ), 10, 3 );
			add_action( 'elementor_pro/forms/new_record', array( __CLASS__, 'capture_elementor_forms_submission' ), 10, 2 );
		}

		/**
		 * Activation callback.
		 *
		 * @return void
		 */
		public static function activate() {
			self::create_table();
			self::schedule_weekly_report();
		}

		/**
		 * Deactivation callback.
		 *
		 * @return void
		 */
		public static function deactivate() {
			wp_clear_scheduled_hook( self::CRON_HOOK );
		}

		/**
		 * Add custom weekly cron interval.
		 *
		 * @param array<string,array<string,mixed>> $schedules Cron schedules.
		 * @return array<string,array<string,mixed>>
		 */
		public static function add_weekly_schedule( $schedules ) {
			if ( ! isset( $schedules['m4u_weekly'] ) ) {
				$schedules['m4u_weekly'] = array(
					'interval' => WEEK_IN_SECONDS,
					'display'  => esc_html__( 'Once Weekly', 'simple-submission-log-weekly-report' ),
				);
			}

			return $schedules;
		}

		/**
		 * Schedule weekly report.
		 *
		 * @return void
		 */
		public static function schedule_weekly_report() {
			if ( ! wp_next_scheduled( self::CRON_HOOK ) ) {
				$first_run = current_time( 'timestamp' ) + HOUR_IN_SECONDS;
				wp_schedule_event( $first_run, 'm4u_weekly', self::CRON_HOOK );
			}
		}

		/**
		 * Get database table name.
		 *
		 * @return string
		 */
		public static function get_table_name() {
			global $wpdb;

			return $wpdb->prefix . self::TABLE_SUFFIX;
		}

		/**
		 * Create database table.
		 *
		 * @return void
		 */
		public static function create_table() {
			global $wpdb;

			$table_name      = self::get_table_name();
			$charset_collate = $wpdb->get_charset_collate();

			require_once ABSPATH . 'wp-admin/includes/upgrade.php';

			$sql = "CREATE TABLE {$table_name} (
				id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
				created_at DATETIME NOT NULL,
				source VARCHAR(190) NOT NULL DEFAULT '',
				form_name VARCHAR(190) NOT NULL DEFAULT '',
				page_url TEXT NULL,
				ip_address VARCHAR(100) NOT NULL DEFAULT '',
				lead_name VARCHAR(190) NOT NULL DEFAULT '',
				lead_email VARCHAR(190) NOT NULL DEFAULT '',
				lead_phone VARCHAR(100) NOT NULL DEFAULT '',
				payload LONGTEXT NULL,
				PRIMARY KEY  (id),
				KEY created_at (created_at),
				KEY lead_email (lead_email),
				KEY form_name (form_name)
			) {$charset_collate};";

			dbDelta( $sql );
		}

		/**
		 * Get plugin settings.
		 *
		 * @return array<string,string>
		 */
		public static function get_settings() {
			$defaults = array(
				'report_recipients' => (string) get_option( 'admin_email', '' ),
				'report_enabled'    => 'yes',
				'report_subject'    => __( 'Simple Submission Log Weekly Report', 'simple-submission-log-weekly-report' ),
			);

			$settings = get_option( self::OPTION_KEY, array() );

			if ( ! is_array( $settings ) ) {
				$settings = array();
			}

			return wp_parse_args( $settings, $defaults );
		}

		/**
		 * Register admin menu.
		 *
		 * @return void
		 */
		public static function register_admin_menu() {
			add_menu_page(
				esc_html__( 'Simple Submission Log', 'simple-submission-log-weekly-report' ),
				esc_html__( 'Simple Submission Log', 'simple-submission-log-weekly-report' ),
				'manage_options',
				self::MENU_SLUG,
				array( __CLASS__, 'render_submissions_page' ),
				'dashicons-feedback',
				26
			);

			add_submenu_page(
				self::MENU_SLUG,
				esc_html__( 'All Submissions', 'simple-submission-log-weekly-report' ),
				esc_html__( 'All Submissions', 'simple-submission-log-weekly-report' ),
				'manage_options',
				self::MENU_SLUG,
				array( __CLASS__, 'render_submissions_page' )
			);

			add_submenu_page(
				self::MENU_SLUG,
				esc_html__( 'Weekly Report Settings', 'simple-submission-log-weekly-report' ),
				esc_html__( 'Settings', 'simple-submission-log-weekly-report' ),
				'manage_options',
				'm4u-submission-log-settings',
				array( __CLASS__, 'render_settings_page' )
			);
		}

		/**
		 * Register settings.
		 *
		 * @return void
		 */
		public static function register_settings() {
			register_setting(
				'm4u_submission_log_settings_group',
				self::OPTION_KEY,
				array(
					'sanitize_callback' => array( __CLASS__, 'sanitize_settings' ),
					'default'           => self::get_settings(),
					'type'              => 'array',
				)
			);
		}

		/**
		 * Sanitize plugin settings.
		 *
		 * @param mixed $input Raw settings.
		 * @return array<string,string>
		 */
		public static function sanitize_settings( $input ) {
			$input = is_array( $input ) ? $input : array();

			$recipient_list = '';
			if ( isset( $input['report_recipients'] ) ) {
				$emails = array_map( 'trim', explode( ',', (string) $input['report_recipients'] ) );
				$emails = array_filter( $emails, 'is_email' );
				$recipient_list = implode( ',', $emails );
			}

			return array(
				'report_recipients' => $recipient_list,
				'report_enabled'    => ( isset( $input['report_enabled'] ) && 'yes' === $input['report_enabled'] ) ? 'yes' : 'no',
				'report_subject'    => isset( $input['report_subject'] ) ? sanitize_text_field( (string) $input['report_subject'] ) : '',
			);
		}

		/**
		 * Add privacy policy helper text.
		 *
		 * @return void
		 */
		public static function maybe_add_privacy_content() {
			if ( ! function_exists( 'wp_add_privacy_policy_content' ) ) {
				return;
			}

			$content = '<p>' . esc_html__( 'This plugin stores form submissions locally in your WordPress database. Stored data may include name, email address, phone number, IP address, page URL, and any fields submitted through supported forms. The plugin can also send a weekly CSV report by email to configured recipients.', 'simple-submission-log-weekly-report' ) . '</p>';

			wp_add_privacy_policy_content(
				esc_html__( 'Simple Submission Log and Weekly Report', 'simple-submission-log-weekly-report' ),
				wp_kses_post( $content )
			);
		}

		/**
		 * Register privacy exporter.
		 *
		 * @param array<string,array<string,mixed>> $exporters Exporters.
		 * @return array<string,array<string,mixed>>
		 */
		public static function register_privacy_exporter( $exporters ) {
			$exporters['simple-submission-log-weekly-report'] = array(
				'exporter_friendly_name' => esc_html__( 'Submission Log Entries', 'simple-submission-log-weekly-report' ),
				'callback'               => array( __CLASS__, 'privacy_exporter' ),
			);

			return $exporters;
		}

		/**
		 * Register privacy eraser.
		 *
		 * @param array<string,array<string,mixed>> $erasers Erasers.
		 * @return array<string,array<string,mixed>>
		 */
		public static function register_privacy_eraser( $erasers ) {
			$erasers['simple-submission-log-weekly-report'] = array(
				'eraser_friendly_name' => esc_html__( 'Submission Log Entries', 'simple-submission-log-weekly-report' ),
				'callback'             => array( __CLASS__, 'privacy_eraser' ),
			);

			return $erasers;
		}

		/**
		 * Privacy exporter callback.
		 *
		 * @param string $email_address Email address.
		 * @param int    $page          Page number.
		 * @return array<string,mixed>
		 */
		public static function privacy_exporter( $email_address, $page = 1 ) {
			global $wpdb;

			$page         = max( 1, (int) $page );
			$number       = 100;
			$offset       = ( $page - 1 ) * $number;
			$email        = sanitize_email( $email_address );
			$export_items = array();

			if ( ! is_email( $email ) ) {
				return array(
					'data' => array(),
					'done' => true,
				);
			}

			$query = $wpdb->prepare(
				"SELECT * FROM " . self::get_table_name() . ' WHERE lead_email = %s ORDER BY id ASC LIMIT %d OFFSET %d',
				$email,
				$number,
				$offset
			);

			$submissions = $wpdb->get_results( $query );

			foreach ( $submissions as $submission ) {
				$payload = json_decode( (string) $submission->payload, true );
				$payload = is_array( $payload ) ? $payload : array();

				$item_data = array(
					array(
						'name'  => esc_html__( 'Date', 'simple-submission-log-weekly-report' ),
						'value' => $submission->created_at,
					),
					array(
						'name'  => esc_html__( 'Source', 'simple-submission-log-weekly-report' ),
						'value' => $submission->source,
					),
					array(
						'name'  => esc_html__( 'Form Name', 'simple-submission-log-weekly-report' ),
						'value' => $submission->form_name,
					),
					array(
						'name'  => esc_html__( 'Page URL', 'simple-submission-log-weekly-report' ),
						'value' => $submission->page_url,
					),
					array(
						'name'  => esc_html__( 'IP Address', 'simple-submission-log-weekly-report' ),
						'value' => $submission->ip_address,
					),
					array(
						'name'  => esc_html__( 'Submitted Data', 'simple-submission-log-weekly-report' ),
						'value' => wp_json_encode( $payload ),
					),
				);

				$export_items[] = array(
					'group_id'    => 'simple-submission-log-weekly-report',
					'group_label' => esc_html__( 'Submission Log Entries', 'simple-submission-log-weekly-report' ),
					'item_id'     => 'submission-log-' . (int) $submission->id,
					'data'        => $item_data,
				);
			}

			$done = count( $submissions ) < $number;

			return array(
				'data' => $export_items,
				'done' => $done,
			);
		}

		/**
		 * Privacy eraser callback.
		 *
		 * @param string $email_address Email address.
		 * @param int    $page          Page number.
		 * @return array<string,mixed>
		 */
		public static function privacy_eraser( $email_address, $page = 1 ) {
			global $wpdb;

			$page   = max( 1, (int) $page );
			$number = 100;
			$offset = ( $page - 1 ) * $number;
			$email  = sanitize_email( $email_address );

			if ( ! is_email( $email ) ) {
				return array(
					'items_removed'  => false,
					'items_retained' => false,
					'messages'       => array(),
					'done'           => true,
				);
			}

			$ids = $wpdb->get_col(
				$wpdb->prepare(
					"SELECT id FROM " . self::get_table_name() . ' WHERE lead_email = %s ORDER BY id ASC LIMIT %d OFFSET %d',
					$email,
					$number,
					$offset
				)
			);

			$items_removed = false;
			foreach ( $ids as $id ) {
				$deleted = $wpdb->delete( self::get_table_name(), array( 'id' => (int) $id ), array( '%d' ) );
				if ( $deleted ) {
					$items_removed = true;
				}
			}

			$done = count( $ids ) < $number;

			return array(
				'items_removed'  => $items_removed,
				'items_retained' => false,
				'messages'       => array(),
				'done'           => $done,
			);
		}

		/**
		 * Capture Contact Form 7 submissions.
		 *
		 * @param mixed $contact_form Contact form object.
		 * @return void
		 */
		public static function capture_cf7_submission( $contact_form ) {
			if ( ! class_exists( 'WPCF7_Submission' ) ) {
				return;
			}

			$submission = \WPCF7_Submission::get_instance();
			if ( ! $submission ) {
				return;
			}

			$data = $submission->get_posted_data();
			if ( empty( $data ) || ! is_array( $data ) ) {
				return;
			}

			$form_name = esc_html__( 'Contact Form 7 Form', 'simple-submission-log-weekly-report' );
			if ( is_object( $contact_form ) && method_exists( $contact_form, 'title' ) ) {
				$form_name = sanitize_text_field( (string) $contact_form->title() );
			}

			self::store_submission(
				$data,
				array(
					'source'    => 'Contact Form 7',
					'form_name' => $form_name,
					'page_url'  => self::get_request_referer(),
				)
			);
		}

		/**
		 * Capture WPForms submissions.
		 *
		 * @param array<string,mixed> $fields    Submitted fields.
		 * @param array<string,mixed> $entry     Entry data.
		 * @param array<string,mixed> $form_data Form data.
		 * @param int                 $entry_id  Entry ID.
		 * @return void
		 */
		public static function capture_wpforms_submission( $fields, $entry, $form_data, $entry_id ) {
			unset( $entry, $entry_id );

			$data = array();

			if ( is_array( $fields ) ) {
				foreach ( $fields as $field ) {
					if ( isset( $field['name'] ) ) {
						$label          = sanitize_text_field( (string) $field['name'] );
						$data[ $label ] = isset( $field['value'] ) ? self::prepare_field_value( $field['value'] ) : '';
					}
				}
			}

			if ( empty( $data ) ) {
				return;
			}

			$form_name = esc_html__( 'WPForms Form', 'simple-submission-log-weekly-report' );
			if ( isset( $form_data['settings']['form_title'] ) ) {
				$form_name = sanitize_text_field( (string) $form_data['settings']['form_title'] );
			}

			self::store_submission(
				$data,
				array(
					'source'    => 'WPForms',
					'form_name' => $form_name,
					'page_url'  => self::get_request_referer(),
				)
			);
		}

		/**
		 * Capture Fluent Forms submissions.
		 *
		 * @param int|string $entry_id  Entry ID.
		 * @param mixed      $form_data Form data object or array.
		 * @param mixed      $data      Submitted data.
		 * @return void
		 */
		public static function capture_fluent_forms_submission( $entry_id, $form_data, $data ) {
			unset( $entry_id );

			if ( empty( $data ) || ! is_array( $data ) ) {
				return;
			}

			$form_name = esc_html__( 'Fluent Forms Form', 'simple-submission-log-weekly-report' );
			if ( is_object( $form_data ) && isset( $form_data->title ) ) {
				$form_name = sanitize_text_field( (string) $form_data->title );
			} elseif ( is_array( $form_data ) && isset( $form_data['title'] ) ) {
				$form_name = sanitize_text_field( (string) $form_data['title'] );
			}

			self::store_submission(
				$data,
				array(
					'source'    => 'Fluent Forms',
					'form_name' => $form_name,
					'page_url'  => self::get_request_referer(),
				)
			);
		}

		/**
		 * Capture Elementor Pro submissions.
		 *
		 * @param mixed $record  Elementor record.
		 * @param mixed $handler Elementor handler.
		 * @return void
		 */
		public static function capture_elementor_forms_submission( $record, $handler ) {
			unset( $handler );

			if ( ! is_object( $record ) || ! method_exists( $record, 'get' ) ) {
				return;
			}

			$raw_fields = $record->get( 'fields' );
			if ( empty( $raw_fields ) || ! is_array( $raw_fields ) ) {
				return;
			}

			$data = array();
			foreach ( $raw_fields as $field_id => $field ) {
				$key = (string) $field_id;
				if ( is_array( $field ) && ! empty( $field['title'] ) ) {
					$key = sanitize_text_field( (string) $field['title'] );
				}

				$value = '';
				if ( is_array( $field ) && array_key_exists( 'value', $field ) ) {
					$value = self::prepare_field_value( $field['value'] );
				}

				$data[ $key ] = $value;
			}

			if ( empty( $data ) ) {
				return;
			}

			$form_name = esc_html__( 'Elementor Form', 'simple-submission-log-weekly-report' );
			if ( method_exists( $record, 'get_form_settings' ) ) {
				$maybe_form_name = $record->get_form_settings( 'form_name' );
				if ( ! empty( $maybe_form_name ) ) {
					$form_name = sanitize_text_field( (string) $maybe_form_name );
				}
			}

			self::store_submission(
				$data,
				array(
					'source'    => 'Elementor Forms',
					'form_name' => $form_name,
					'page_url'  => self::get_request_referer(),
				)
			);
		}

		/**
		 * Capture external/custom submissions.
		 *
		 * @param mixed $data Submission data.
		 * @param mixed $meta Submission meta.
		 * @return void
		 */
		public static function capture_submission( $data, $meta = array() ) {
			self::store_submission( $data, $meta );
		}

		/**
		 * Store one submission.
		 *
		 * @param mixed $data Submission data.
		 * @param mixed $meta Submission meta.
		 * @return bool
		 */
		public static function store_submission( $data, $meta = array() ) {
			global $wpdb;

			if ( empty( $data ) || ! is_array( $data ) ) {
				return false;
			}

			$data = self::sanitize_recursive( $data );
			$meta = is_array( $meta ) ? self::sanitize_recursive( $meta ) : array();

			$lead_email = self::extract_email_value( $data );
			$lead_phone = self::extract_phone_value( $data );
			$lead_name  = self::extract_name_value( $data, $lead_email, $lead_phone );

			$inserted = $wpdb->insert(
				self::get_table_name(),
				array(
					'created_at' => current_time( 'mysql' ),
					'source'     => isset( $meta['source'] ) ? sanitize_text_field( (string) $meta['source'] ) : esc_html__( 'Custom Form', 'simple-submission-log-weekly-report' ),
					'form_name'  => isset( $meta['form_name'] ) ? sanitize_text_field( (string) $meta['form_name'] ) : esc_html__( 'Submission', 'simple-submission-log-weekly-report' ),
					'page_url'   => isset( $meta['page_url'] ) ? esc_url_raw( (string) $meta['page_url'] ) : '',
					'ip_address' => self::get_user_ip_address(),
					'lead_name'  => sanitize_text_field( $lead_name ),
					'lead_email' => sanitize_email( $lead_email ),
					'lead_phone' => sanitize_text_field( $lead_phone ),
					'payload'    => wp_json_encode( $data ),
				),
				array( '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s' )
			);

			return (bool) $inserted;
		}

		/**
		 * Sanitize recursive data.
		 *
		 * @param mixed $value Value to sanitize.
		 * @return mixed
		 */
		public static function sanitize_recursive( $value ) {
			if ( is_array( $value ) ) {
				foreach ( $value as $key => $item ) {
					$value[ $key ] = self::sanitize_recursive( $item );
				}

				return $value;
			}

			if ( is_object( $value ) ) {
				return self::sanitize_recursive( (array) $value );
			}

			return is_scalar( $value ) ? sanitize_textarea_field( (string) $value ) : '';
		}

		/**
		 * Prepare raw field values for storage.
		 *
		 * @param mixed $value Field value.
		 * @return mixed
		 */
		public static function prepare_field_value( $value ) {
			if ( is_array( $value ) ) {
				return array_map( array( __CLASS__, 'prepare_field_value' ), $value );
			}

			if ( is_object( $value ) ) {
				return self::prepare_field_value( (array) $value );
			}

			return is_scalar( $value ) ? (string) $value : '';
		}

		/**
		 * Extract first matching value from flattened payload.
		 *
		 * @param array<string,mixed> $data       Submission data.
		 * @param array<int,string>   $candidates Candidate keys.
		 * @return string
		 */
		public static function extract_first_matching_value( $data, $candidates ) {
			$flat = self::flatten_array( $data );

			foreach ( $flat as $key => $value ) {
				$normalized = strtolower( str_replace( array( '-', '_', ' ' ), '', (string) $key ) );
				foreach ( $candidates as $candidate ) {
					$candidate_normalized = strtolower( str_replace( array( '-', '_', ' ' ), '', $candidate ) );
					if ( false !== strpos( $normalized, $candidate_normalized ) && '' !== trim( (string) $value ) ) {
						return is_array( $value ) ? implode( ', ', $value ) : (string) $value;
					}
				}
			}

			return '';
		}

		/**
		 * Extract an email value from submitted data.
		 *
		 * @param array<string,mixed> $data Submission data.
		 * @return string
		 */
		public static function extract_email_value( $data ) {
			$email = self::extract_first_matching_value(
				$data,
				array( 'email', 'your-email', 'e-mail', 'mail', 'אימייל', 'דואל', 'דואר אלקטרוני' )
			);

			if ( is_email( $email ) ) {
				return $email;
			}

			$flat = self::flatten_array( $data );
			foreach ( $flat as $value ) {
				$candidate = is_array( $value ) ? implode( ', ', $value ) : (string) $value;
				$candidate = trim( $candidate );
				if ( is_email( $candidate ) ) {
					return $candidate;
				}
			}

			return '';
		}

		/**
		 * Extract a phone value from submitted data.
		 *
		 * @param array<string,mixed> $data Submission data.
		 * @return string
		 */
		public static function extract_phone_value( $data ) {
			$phone = self::extract_first_matching_value(
				$data,
				array( 'phone', 'mobile', 'tel', 'telephone', 'your-phone', 'whatsapp', 'טלפון', 'נייד', 'פלאפון', 'נייד/טלפון' )
			);

			if ( self::is_phone_like( $phone ) ) {
				return $phone;
			}

			$flat = self::flatten_array( $data );
			foreach ( $flat as $value ) {
				$candidate = is_array( $value ) ? implode( ', ', $value ) : (string) $value;
				if ( self::is_phone_like( $candidate ) ) {
					return trim( $candidate );
				}
			}

			return '';
		}

		/**
		 * Extract a lead name from submitted data.
		 *
		 * @param array<string,mixed> $data       Submission data.
		 * @param string              $lead_email Extracted email.
		 * @param string              $lead_phone Extracted phone.
		 * @return string
		 */
		public static function extract_name_value( $data, $lead_email = '', $lead_phone = '' ) {
			$name = self::extract_first_matching_value(
				$data,
				array( 'name', 'full_name', 'fullname', 'your-name', 'first_name', 'first name', 'שם', 'שם מלא', 'fullname' )
			);

			if ( '' !== trim( $name ) && ! is_email( $name ) && ! self::is_phone_like( $name ) ) {
				return trim( $name );
			}

			$flat = self::flatten_array( $data );
			foreach ( $flat as $key => $value ) {
				$candidate = is_array( $value ) ? implode( ', ', $value ) : (string) $value;
				$candidate = trim( $candidate );

				if ( '' === $candidate || is_email( $candidate ) || self::is_phone_like( $candidate ) ) {
					continue;
				}

				if ( '' !== $lead_email && $candidate === $lead_email ) {
					continue;
				}

				if ( '' !== $lead_phone && $candidate === $lead_phone ) {
					continue;
				}

				$normalized_key = strtolower( str_replace( array( '-', '_', ' ' ), '', (string) $key ) );
				$skip_keys       = array( 'accept', 'consent', 'privacy', 'gdpr', 'terms', 'message', 'comments', 'comment', 'textarea', 'הסכמה', 'אישור' );
				$should_skip     = false;
				foreach ( $skip_keys as $skip_key ) {
					$skip_key = strtolower( str_replace( array( '-', '_', ' ' ), '', (string) $skip_key ) );
					if ( false !== strpos( $normalized_key, $skip_key ) ) {
						$should_skip = true;
						break;
					}
				}

				if ( $should_skip ) {
					continue;
				}

				return $candidate;
			}

			return '';
		}

		/**
		 * Check whether a value looks like a phone number.
		 *
		 * @param string $value Raw value.
		 * @return bool
		 */
		public static function is_phone_like( $value ) {
			$value = trim( (string) $value );
			if ( '' === $value || is_email( $value ) ) {
				return false;
			}

			$normalized = preg_replace( '/[^0-9+]/', '', $value );
			if ( ! is_string( $normalized ) ) {
				return false;
			}

			$digit_count = strlen( preg_replace( '/\D/', '', $normalized ) );

			return $digit_count >= 7 && $digit_count <= 16;
		}

		/**
		 * Flatten nested array for searching and CSV output.
		 *
		 * @param array<string,mixed> $array  Source array.
		 * @param string              $prefix Prefix.
		 * @return array<string,mixed>
		 */
		public static function flatten_array( $array, $prefix = '' ) {
			$result = array();

			foreach ( (array) $array as $key => $value ) {
				$new_key = '' === $prefix ? (string) $key : $prefix . '.' . $key;
				if ( is_array( $value ) ) {
					$result = array_merge( $result, self::flatten_array( $value, $new_key ) );
				} else {
					$result[ $new_key ] = $value;
				}
			}

			return $result;
		}

		/**
		 * Get user IP address.
		 *
		 * @return string
		 */
		public static function get_user_ip_address() {
			$keys = array( 'HTTP_CLIENT_IP', 'HTTP_X_FORWARDED_FOR', 'REMOTE_ADDR' );

			foreach ( $keys as $key ) {
				if ( empty( $_SERVER[ $key ] ) ) {
					continue;
				}

				$value = wp_unslash( $_SERVER[ $key ] );
				if ( 'HTTP_X_FORWARDED_FOR' === $key ) {
					$parts = explode( ',', $value );
					$value = trim( $parts[0] );
				}

				return sanitize_text_field( $value );
			}

			return '';
		}

		/**
		 * Get request referer URL.
		 *
		 * @return string
		 */
		public static function get_request_referer() {
			if ( empty( $_SERVER['HTTP_REFERER'] ) ) {
				return '';
			}

			return esc_url_raw( wp_unslash( $_SERVER['HTTP_REFERER'] ) );
		}

		/**
		 * Get submissions for the weekly report.
		 *
		 * @param array<string,string> $args Query args.
		 * @return array<int,object>
		 */
		public static function get_submissions( $args = array() ) {
			global $wpdb;

			$current_timestamp = current_time( 'timestamp' );
			$defaults          = array(
				'start_date' => wp_date( 'Y-m-d H:i:s', $current_timestamp - WEEK_IN_SECONDS ),
				'end_date'   => wp_date( 'Y-m-d H:i:s', $current_timestamp ),
			);

			$args = wp_parse_args( $args, $defaults );

			$sql = $wpdb->prepare(
				"SELECT * FROM " . self::get_table_name() . ' WHERE created_at >= %s AND created_at <= %s ORDER BY created_at ASC',
				$args['start_date'],
				$args['end_date']
			);

			return $wpdb->get_results( $sql );
		}

		/**
		 * Build CSV file for given submissions.
		 *
		 * @param array<int,object> $submissions Submission rows.
		 * @return string|false
		 */
		public static function build_csv_file( $submissions ) {
			$temp_file = wp_tempnam( 'simple-submission-log-weekly-report.csv' );
			if ( ! $temp_file ) {
				return false;
			}

			$handle = fopen( $temp_file, 'w' );
			if ( ! $handle ) {
				return false;
			}

			fwrite( $handle, "\xEF\xBB\xBF" );

			$headers         = array( 'ID', 'Date', 'Source', 'Form', 'Name', 'Email', 'Phone', 'Page URL', 'IP Address' );
			$dynamic_headers = array();
			$rows            = array();

			foreach ( $submissions as $submission ) {
				$payload = json_decode( (string) $submission->payload, true );
				$flat    = self::flatten_array( is_array( $payload ) ? $payload : array() );

				foreach ( array_keys( $flat ) as $key ) {
					if ( ! in_array( $key, $dynamic_headers, true ) ) {
						$dynamic_headers[] = $key;
					}
				}

				$rows[] = array(
					'base' => array(
						$submission->id,
						$submission->created_at,
						$submission->source,
						$submission->form_name,
						$submission->lead_name,
						$submission->lead_email,
						$submission->lead_phone,
						$submission->page_url,
						$submission->ip_address,
					),
					'flat' => $flat,
				);
			}

			fputcsv( $handle, array_merge( $headers, $dynamic_headers ) );

			foreach ( $rows as $row ) {
				$line = $row['base'];
				foreach ( $dynamic_headers as $header ) {
					$line[] = isset( $row['flat'][ $header ] ) ? self::stringify_csv_value( $row['flat'][ $header ] ) : '';
				}
				fputcsv( $handle, $line );
			}

			fclose( $handle );

			return $temp_file;
		}

		/**
		 * Convert values to CSV-safe strings.
		 *
		 * @param mixed $value Value.
		 * @return string
		 */
		public static function stringify_csv_value( $value ) {
			if ( is_array( $value ) ) {
				return implode( ', ', array_map( 'strval', $value ) );
			}

			if ( is_bool( $value ) ) {
				return $value ? '1' : '0';
			}

			return (string) $value;
		}

		/**
		 * Get admin list data.
		 *
		 * @param string $search Search string.
		 * @param int    $limit  Row limit.
		 * @param int    $offset Row offset.
		 * @return array<int,object>
		 */
		public static function get_submissions_for_admin( $search = '', $limit = 20, $offset = 0 ) {
			global $wpdb;

			$table_name = self::get_table_name();
			$search     = trim( $search );

			if ( '' !== $search ) {
				$like = '%' . $wpdb->esc_like( $search ) . '%';
				$sql  = $wpdb->prepare(
					"SELECT * FROM {$table_name} WHERE lead_name LIKE %s OR lead_email LIKE %s OR lead_phone LIKE %s OR form_name LIKE %s OR source LIKE %s OR payload LIKE %s ORDER BY created_at DESC LIMIT %d OFFSET %d",
					$like,
					$like,
					$like,
					$like,
					$like,
					$like,
					$limit,
					$offset
				);
			} else {
				$sql = $wpdb->prepare(
					"SELECT * FROM {$table_name} ORDER BY created_at DESC LIMIT %d OFFSET %d",
					$limit,
					$offset
				);
			}

			return $wpdb->get_results( $sql );
		}

		/**
		 * Count admin list items.
		 *
		 * @param string $search Search string.
		 * @return int
		 */
		public static function get_admin_submissions_count( $search = '' ) {
			global $wpdb;

			$table_name = self::get_table_name();
			$search     = trim( $search );

			if ( '' !== $search ) {
				$like = '%' . $wpdb->esc_like( $search ) . '%';
				$sql  = $wpdb->prepare(
					"SELECT COUNT(*) FROM {$table_name} WHERE lead_name LIKE %s OR lead_email LIKE %s OR lead_phone LIKE %s OR form_name LIKE %s OR source LIKE %s OR payload LIKE %s",
					$like,
					$like,
					$like,
					$like,
					$like,
					$like
				);
				return (int) $wpdb->get_var( $sql );
			}

			return (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table_name}" );
		}

		/**
		 * Get one submission by ID.
		 *
		 * @param int $submission_id Submission ID.
		 * @return object|null
		 */
		public static function get_submission_by_id( $submission_id ) {
			global $wpdb;

			$sql = $wpdb->prepare( "SELECT * FROM " . self::get_table_name() . ' WHERE id = %d', $submission_id );

			return $wpdb->get_row( $sql );
		}

		/**
		 * Render admin submissions page.
		 *
		 * @return void
		 */
		public static function render_submissions_page() {
			if ( ! current_user_can( 'manage_options' ) ) {
				return;
			}

			$search   = isset( $_GET['s'] ) ? sanitize_text_field( wp_unslash( $_GET['s'] ) ) : '';
			$per_page = 20;
			$paged    = isset( $_GET['paged_no'] ) ? max( 1, absint( $_GET['paged_no'] ) ) : 1;
			$offset   = ( $paged - 1 ) * $per_page;
			$view_id  = isset( $_GET['view_submission'] ) ? absint( $_GET['view_submission'] ) : 0;

			$total_items = self::get_admin_submissions_count( $search );
			$rows        = self::get_submissions_for_admin( $search, $per_page, $offset );

			$export_url = wp_nonce_url(
				add_query_arg(
					array(
						'action' => 'm4u_submission_export_csv',
						's'      => $search,
					),
					admin_url( 'admin-post.php' )
				),
				'm4u_submission_export_csv'
			);

			$send_now_url = wp_nonce_url(
				add_query_arg(
					array(
						'action' => 'm4u_submission_send_report_now',
					),
					admin_url( 'admin-post.php' )
				),
				'm4u_submission_send_report_now'
			);

			$notice = isset( $_GET['m4u_notice'] ) ? sanitize_key( wp_unslash( $_GET['m4u_notice'] ) ) : '';
			?>
			<div class="wrap">
				<h1><?php esc_html_e( 'Submission Log', 'simple-submission-log-weekly-report' ); ?></h1>
				<p><?php esc_html_e( 'Stores form submissions and lets you export or email a weekly CSV report.', 'simple-submission-log-weekly-report' ); ?></p>

				<?php if ( 'report_sent' === $notice ) : ?>
					<div class="notice notice-success is-dismissible"><p><?php esc_html_e( 'Weekly report email sent.', 'simple-submission-log-weekly-report' ); ?></p></div>
				<?php elseif ( 'report_failed' === $notice ) : ?>
					<div class="notice notice-error is-dismissible"><p><?php esc_html_e( 'Weekly report could not be sent.', 'simple-submission-log-weekly-report' ); ?></p></div>
				<?php endif; ?>

				<form method="get" style="margin:16px 0;">
					<input type="hidden" name="page" value="<?php echo esc_attr( self::MENU_SLUG ); ?>" />
					<input type="search" name="s" value="<?php echo esc_attr( $search ); ?>" placeholder="<?php esc_attr_e( 'Search submissions…', 'simple-submission-log-weekly-report' ); ?>" class="regular-text" />
					<button type="submit" class="button"><?php esc_html_e( 'Search', 'simple-submission-log-weekly-report' ); ?></button>
					<a href="<?php echo esc_url( $export_url ); ?>" class="button button-secondary"><?php esc_html_e( 'Export CSV', 'simple-submission-log-weekly-report' ); ?></a>
					<a href="<?php echo esc_url( $send_now_url ); ?>" class="button button-secondary"><?php esc_html_e( 'Send Weekly Report Now', 'simple-submission-log-weekly-report' ); ?></a>
				</form>

				<?php if ( $view_id ) : ?>
					<?php $item = self::get_submission_by_id( $view_id ); ?>
					<?php if ( $item ) : ?>
						<?php $payload = json_decode( (string) $item->payload, true ); ?>
						<div style="background:#fff;border:1px solid #ccd0d4;padding:16px;margin:16px 0;">
							<h2><?php echo esc_html( sprintf( __( 'Submission #%d', 'simple-submission-log-weekly-report' ), (int) $item->id ) ); ?></h2>
							<p><strong><?php esc_html_e( 'Date:', 'simple-submission-log-weekly-report' ); ?></strong> <?php echo esc_html( $item->created_at ); ?></p>
							<p><strong><?php esc_html_e( 'Source:', 'simple-submission-log-weekly-report' ); ?></strong> <?php echo esc_html( $item->source ); ?></p>
							<p><strong><?php esc_html_e( 'Form:', 'simple-submission-log-weekly-report' ); ?></strong> <?php echo esc_html( $item->form_name ); ?></p>
							<p><strong><?php esc_html_e( 'Name:', 'simple-submission-log-weekly-report' ); ?></strong> <?php echo esc_html( $item->lead_name ); ?></p>
							<p><strong><?php esc_html_e( 'Email:', 'simple-submission-log-weekly-report' ); ?></strong> <?php echo esc_html( $item->lead_email ); ?></p>
							<p><strong><?php esc_html_e( 'Phone:', 'simple-submission-log-weekly-report' ); ?></strong> <?php echo esc_html( $item->lead_phone ); ?></p>
							<p><strong><?php esc_html_e( 'Page URL:', 'simple-submission-log-weekly-report' ); ?></strong> <?php echo esc_html( $item->page_url ); ?></p>
							<p><strong><?php esc_html_e( 'IP Address:', 'simple-submission-log-weekly-report' ); ?></strong> <?php echo esc_html( $item->ip_address ); ?></p>
							<h3><?php esc_html_e( 'Submitted Data', 'simple-submission-log-weekly-report' ); ?></h3>
							<textarea readonly="readonly" style="width:100%;min-height:260px;font-family:monospace;"><?php echo esc_textarea( print_r( $payload, true ) ); ?></textarea>
						</div>
					<?php endif; ?>
				<?php endif; ?>

				<table class="widefat striped">
					<thead>
						<tr>
							<th><?php esc_html_e( 'ID', 'simple-submission-log-weekly-report' ); ?></th>
							<th><?php esc_html_e( 'Date', 'simple-submission-log-weekly-report' ); ?></th>
							<th><?php esc_html_e( 'Source', 'simple-submission-log-weekly-report' ); ?></th>
							<th><?php esc_html_e( 'Form', 'simple-submission-log-weekly-report' ); ?></th>
							<th><?php esc_html_e( 'Name', 'simple-submission-log-weekly-report' ); ?></th>
							<th><?php esc_html_e( 'Email', 'simple-submission-log-weekly-report' ); ?></th>
							<th><?php esc_html_e( 'Phone', 'simple-submission-log-weekly-report' ); ?></th>
							<th><?php esc_html_e( 'Actions', 'simple-submission-log-weekly-report' ); ?></th>
						</tr>
					</thead>
					<tbody>
						<?php if ( ! empty( $rows ) ) : ?>
							<?php foreach ( $rows as $row ) : ?>
								<tr>
									<td><?php echo esc_html( (string) $row->id ); ?></td>
									<td><?php echo esc_html( $row->created_at ); ?></td>
									<td><?php echo esc_html( $row->source ); ?></td>
									<td><?php echo esc_html( $row->form_name ); ?></td>
									<td><?php echo esc_html( $row->lead_name ); ?></td>
									<td><?php echo esc_html( $row->lead_email ); ?></td>
									<td><?php echo esc_html( $row->lead_phone ); ?></td>
									<td>
										<a class="button button-small" href="<?php echo esc_url( add_query_arg( array( 'page' => self::MENU_SLUG, 'view_submission' => (int) $row->id ), admin_url( 'admin.php' ) ) ); ?>"><?php esc_html_e( 'View', 'simple-submission-log-weekly-report' ); ?></a>
									</td>
								</tr>
							<?php endforeach; ?>
						<?php else : ?>
							<tr>
								<td colspan="8"><?php esc_html_e( 'No submissions found.', 'simple-submission-log-weekly-report' ); ?></td>
							</tr>
						<?php endif; ?>
					</tbody>
				</table>

				<?php
				$total_pages = (int) ceil( $total_items / $per_page );
				if ( $total_pages > 1 ) {
					echo '<div style="margin-top:16px;">';
					echo wp_kses_post(
						paginate_links(
							array(
								'base'      => add_query_arg(
									array(
										'page'     => self::MENU_SLUG,
										's'        => $search,
										'paged_no' => '%#%',
									),
									admin_url( 'admin.php' )
								),
								'format'    => '',
								'current'   => $paged,
								'total'     => $total_pages,
								'prev_text' => '&laquo;',
								'next_text' => '&raquo;',
							)
						)
					);
					echo '</div>';
				}
				?>
			</div>
			<?php
		}

		/**
		 * Render settings page.
		 *
		 * @return void
		 */
		public static function render_settings_page() {
			if ( ! current_user_can( 'manage_options' ) ) {
				return;
			}

			$settings = self::get_settings();
			?>
			<div class="wrap">
				<h1><?php esc_html_e( 'Weekly Report Settings', 'simple-submission-log-weekly-report' ); ?></h1>
				<form method="post" action="options.php">
					<?php settings_fields( 'm4u_submission_log_settings_group' ); ?>
					<table class="form-table" role="presentation">
						<tr>
							<th scope="row"><label for="m4u_report_enabled"><?php esc_html_e( 'Enable weekly email report', 'simple-submission-log-weekly-report' ); ?></label></th>
							<td>
								<select id="m4u_report_enabled" name="<?php echo esc_attr( self::OPTION_KEY ); ?>[report_enabled]">
									<option value="yes" <?php selected( $settings['report_enabled'], 'yes' ); ?>><?php esc_html_e( 'Yes', 'simple-submission-log-weekly-report' ); ?></option>
									<option value="no" <?php selected( $settings['report_enabled'], 'no' ); ?>><?php esc_html_e( 'No', 'simple-submission-log-weekly-report' ); ?></option>
								</select>
							</td>
						</tr>
						<tr>
							<th scope="row"><label for="m4u_report_recipients"><?php esc_html_e( 'Report recipients', 'simple-submission-log-weekly-report' ); ?></label></th>
							<td>
								<input id="m4u_report_recipients" type="text" class="regular-text" name="<?php echo esc_attr( self::OPTION_KEY ); ?>[report_recipients]" value="<?php echo esc_attr( $settings['report_recipients'] ); ?>" />
								<p class="description"><?php esc_html_e( 'Comma-separated email addresses. Leave blank to use the site admin email.', 'simple-submission-log-weekly-report' ); ?></p>
							</td>
						</tr>
						<tr>
							<th scope="row"><label for="m4u_report_subject"><?php esc_html_e( 'Email subject', 'simple-submission-log-weekly-report' ); ?></label></th>
							<td>
								<input id="m4u_report_subject" type="text" class="regular-text" name="<?php echo esc_attr( self::OPTION_KEY ); ?>[report_subject]" value="<?php echo esc_attr( $settings['report_subject'] ); ?>" />
							</td>
						</tr>
						<tr>
							<th scope="row"><?php esc_html_e( 'Report format', 'simple-submission-log-weekly-report' ); ?></th>
							<td>
								<strong><?php esc_html_e( 'CSV', 'simple-submission-log-weekly-report' ); ?></strong>
								<p class="description"><?php esc_html_e( 'CSV opens in Excel and Google Sheets.', 'simple-submission-log-weekly-report' ); ?></p>
							</td>
						</tr>
					</table>
					<?php submit_button(); ?>
				</form>

				<hr />
				<h2><?php esc_html_e( 'Custom form usage', 'simple-submission-log-weekly-report' ); ?></h2>
				<p><?php esc_html_e( 'If your form is custom, call one of these from your existing plugin after a successful submit:', 'simple-submission-log-weekly-report' ); ?></p>
				<textarea readonly="readonly" style="width:100%;min-height:140px;font-family:monospace;"><?php echo esc_textarea( "m4u_submission_logger_store_submission( \$array_data, array(
    'source'    => 'Website Form',
    'form_name' => 'Main Form',
    'page_url'  => home_url( '/' ),
) );

// Or:
do_action( 'm4u_submission_logger_capture', \$array_data, array(
    'source'    => 'Website Form',
    'form_name' => 'Main Form',
) );" ); ?></textarea>
			</div>
			<?php
		}

		/**
		 * Send weekly report.
		 *
		 * @return bool
		 */
		public static function send_weekly_report() {
			$settings = self::get_settings();
			if ( 'yes' !== $settings['report_enabled'] ) {
				return false;
			}

			$submissions = self::get_submissions();
			$csv_file    = self::build_csv_file( $submissions );

			if ( ! $csv_file ) {
				return false;
			}

			$recipients = array();
			if ( ! empty( $settings['report_recipients'] ) ) {
				$recipients = array_filter( array_map( 'trim', explode( ',', $settings['report_recipients'] ) ), 'is_email' );
			}

			if ( empty( $recipients ) ) {
				$admin_email = (string) get_option( 'admin_email', '' );
				if ( is_email( $admin_email ) ) {
					$recipients[] = $admin_email;
				}
			}

			if ( empty( $recipients ) ) {
				wp_delete_file( $csv_file );
				return false;
			}

			$subject = ! empty( $settings['report_subject'] ) ? $settings['report_subject'] : __( 'Simple Submission Log Weekly Report', 'simple-submission-log-weekly-report' );
			$message = sprintf(
				/* translators: %d: number of submissions. */
				__( "Hello,\n\nAttached is your weekly website leads report from the last 7 days.\n\nTotal submissions: %d\n\nRegards,", 'simple-submission-log-weekly-report' ),
				count( $submissions )
			);
			$headers = array( 'Content-Type: text/plain; charset=UTF-8' );
			$sent    = wp_mail( implode( ',', $recipients ), $subject, $message, $headers, array( $csv_file ) );

			if ( file_exists( $csv_file ) ) {
				wp_delete_file( $csv_file );
			}

			return (bool) $sent;
		}

		/**
		 * Handle send report now action.
		 *
		 * @return void
		 */
		public static function handle_send_report_now() {
			if ( ! current_user_can( 'manage_options' ) ) {
				wp_die( esc_html__( 'You are not allowed to access this page.', 'simple-submission-log-weekly-report' ) );
			}

			check_admin_referer( 'm4u_submission_send_report_now' );
			$sent = self::send_weekly_report();

			wp_safe_redirect(
				add_query_arg(
					array(
						'page'       => self::MENU_SLUG,
						'm4u_notice' => $sent ? 'report_sent' : 'report_failed',
					),
					admin_url( 'admin.php' )
				)
			);
			exit;
		}

		/**
		 * Handle CSV export.
		 *
		 * @return void
		 */
		public static function handle_export_csv() {
			if ( ! current_user_can( 'manage_options' ) ) {
				wp_die( esc_html__( 'You are not allowed to access this page.', 'simple-submission-log-weekly-report' ) );
			}

			check_admin_referer( 'm4u_submission_export_csv' );

			$search      = isset( $_GET['s'] ) ? sanitize_text_field( wp_unslash( $_GET['s'] ) ) : '';
			$submissions = self::get_submissions_for_admin( $search, 999999, 0 );

			nocache_headers();
			header( 'Content-Type: text/csv; charset=utf-8' );
			header( 'Content-Disposition: attachment; filename=submission-log-' . gmdate( 'Y-m-d-H-i-s' ) . '.csv' );

			$output = fopen( 'php://output', 'w' );
			if ( ! $output ) {
				exit;
			}

			fwrite( $output, "\xEF\xBB\xBF" );

			$headers         = array( 'ID', 'Date', 'Source', 'Form', 'Name', 'Email', 'Phone', 'Page URL', 'IP Address' );
			$dynamic_headers = array();
			$rows            = array();

			foreach ( $submissions as $submission ) {
				$payload = json_decode( (string) $submission->payload, true );
				$flat    = self::flatten_array( is_array( $payload ) ? $payload : array() );

				foreach ( array_keys( $flat ) as $key ) {
					if ( ! in_array( $key, $dynamic_headers, true ) ) {
						$dynamic_headers[] = $key;
					}
				}

				$rows[] = array(
					'base' => array(
						$submission->id,
						$submission->created_at,
						$submission->source,
						$submission->form_name,
						$submission->lead_name,
						$submission->lead_email,
						$submission->lead_phone,
						$submission->page_url,
						$submission->ip_address,
					),
					'flat' => $flat,
				);
			}

			fputcsv( $output, array_merge( $headers, $dynamic_headers ) );

			foreach ( $rows as $row ) {
				$line = $row['base'];
				foreach ( $dynamic_headers as $header ) {
					$line[] = isset( $row['flat'][ $header ] ) ? self::stringify_csv_value( $row['flat'][ $header ] ) : '';
				}
				fputcsv( $output, $line );
			}

			fclose( $output );
			exit;
		}
	}
}

if ( ! function_exists( 'm4u_submission_logger_store_submission' ) ) {
	/**
	 * Store a custom submission from another plugin or theme.
	 *
	 * @param mixed $data Submission data.
	 * @param mixed $meta Submission meta.
	 * @return bool
	 */
	function m4u_submission_logger_store_submission( $data, $meta = array() ) {
		return M4U_Simple_Submission_Log_Weekly_Report::store_submission( $data, $meta );
	}
}

register_activation_hook( __FILE__, array( 'M4U_Simple_Submission_Log_Weekly_Report', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'M4U_Simple_Submission_Log_Weekly_Report', 'deactivate' ) );
M4U_Simple_Submission_Log_Weekly_Report::init();
