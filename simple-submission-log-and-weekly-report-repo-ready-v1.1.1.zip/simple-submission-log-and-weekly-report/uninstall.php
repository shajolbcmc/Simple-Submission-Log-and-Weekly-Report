<?php
/**
 * Uninstall routine for Simple Submission Log and Weekly Report.
 *
 * @package Simple_Submission_Log_Weekly_Report
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

if ( defined( 'M4U_SSLWR_PRESERVE_DATA' ) && M4U_SSLWR_PRESERVE_DATA ) {
	return;
}

global $wpdb;

$option_key   = 'm4u_simple_submission_log_settings';
$table_suffix = 'm4u_submission_log';
$cron_hook    = 'm4u_simple_submission_log_send_weekly_report';
$table_name   = $wpdb->prefix . $table_suffix;

delete_option( $option_key );
delete_site_option( $option_key );
wp_clear_scheduled_hook( $cron_hook );

$wpdb->query( "DROP TABLE IF EXISTS {$table_name}" ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.SchemaChange,WordPress.DB.DirectDatabaseQuery.NoCaching
